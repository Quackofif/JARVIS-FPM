package edu.fra.uas.repository;

public class TaskRepository {

}
