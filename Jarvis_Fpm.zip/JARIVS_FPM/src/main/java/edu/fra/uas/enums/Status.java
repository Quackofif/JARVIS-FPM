package edu.fra.uas.enums;

public enum Status {

	Backlog ("Backlog"),
	Ready ("Ready"),
	In_Progress ("In Progress"),
	Done ("Done");

	Status(String string) {
		// TODO Auto-generated constructor stub
	}
	
	
}
